<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Home Page</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://mbp.yimg.com/sy/os/yaft/yaft-0.3.10.min.js" defer></script>
</head>
<body onload="init();">
  <div style="color:white">
  <h1> Welcome <?php echo $_SESSION['username']; ?></h1>
  </div>
    <div class = "output">
    <?php 
    if(isset($_GET['unfilled'])){
        echo "One or more of the required fields have not been entered. Please try again!";
    }
    ?>
    </div>
   <div id="time" style="color:white;" float="left"></div>
   <div class="login-page">
       <form action="print.php">
       <input type="submit" value="View Your Quiz Scores" class = "adjust">
       <a href="logout.php" class = "logout">Logout</a>
       </form>
    </div>
    </div>


<script type="text/javascript">

function init()
{
    updateTime();
    window.setInterval(updateTime,5000);
}


function updateTime()
{
    var time = document.getElementById('time');
    time.innerText = new Date().toLocaleString();
}

</script>
</body>
</html>

<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db1";


$start="";
$count="";

if(isset($_GET['btn'])){

$start= $_GET['start']; 
$count= $_GET['Result'];

}
 

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO tbl_users (username,scores)
VALUES ('$start','$count')";

if ($conn->query($sql) === TRUE) {//do nothing
} 
else{
 
    echo "Error: " . $sql . "<br>" . $conn->error;
}
header("location:home.php");
$conn->close();
?>

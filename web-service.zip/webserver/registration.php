<?php
    session_start();
   
?>
<!DOCTYPE html>
<html lang ="en">
    <head>
        <meta charset = "utf-8">
        <script src="https://mbp.yimg.com/sy/os/yaft/yaft-0.3.10.min.js" defer></script>
    </head>
    <body>
    
    <?php
$servername = "localhost";



try {
    $username = "root";
    $password = "";
    $conn = new PDO("mysql:host=$servername;dbname=db1", trim($username),trim($password));
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $u = $_POST['user'];
    $passw = $_POST['passw'];
    $e = $_POST['email'];
    if (!$u || !$passw || !$e) {
        header('Location:index.php?unfilled');
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE username ='$u'");
    $stmt->execute();
    $flag = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    $result = $stmt ->fetchAll();
    if (count($result)>0){
        header("Location:index.php?errorCode=wrongUsername");
        exit;
    }else{
        $reg = $conn->prepare("insert into tbl_users(username, password, email) values('$u', '$passw', '$e')");
        $reg->execute();
        header("Location:index.php?success=correctusername");
        exit;
        }
    
    $conn =null;
   }catch(PDOException $e){
   echo "Connection failed: " . $e->getMessage();}
?>
</body>
</html>

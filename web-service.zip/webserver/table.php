<?php
    session_start();
?>
<!DOCTYPE html>
<html lang ="en">
    <head>
        <meta charset = "utf-8">
        <script src="https://mbp.yimg.com/sy/os/yaft/yaft-0.3.10.min.js" defer></script>
    </head>
    <body>
<?php   
    $servername = "localhost";
    $username = "root";
    $password = "";
    $conn = new PDO("mysql:host=$servername;dbname=db1", trim($username),trim($password));
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //variables
    $u = $_SESSION['username'];
    $p = $_SESSION['password'];
    //check if their empty
    if (!$u || !$p ||) {
        header('Location:home.php?unfilled');
        exit;
    }
    //add values to the table    
      $dbservername = "localhost";
      $dbusername = "root";
      $dbpassword = "";
      $dbname = "db1";

// Create connection
$conn = new mysqli($dbservername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$post_email = mysqli_real_escape_string($conn, $_POST['u']);
$sql = "SELECT * FROM tbl_users WHERE username='$post_u'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
        $row = $result->fetch_assoc();
        echo "username: " . $row['username'] . "<br>";
    }
} else {
    echo "0 results";
}

$conn->close();
?>
</body>
</html>
